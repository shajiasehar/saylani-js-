function x(){
alert("Error! Please enter a valid password")}
function y(){
alert("Welcome to JS Land... \n Happy Coding!" )}
function z(){
    alert ("Welcome to JS Land...")
}
function checkpopup(){
 console.log ("Hello... I can run js through my web browser's console")
 alert ("Hello... I can run js through my web browser's console")
}
function welcome(){
    alert("Wellcome to assignment point")
}
function username(){
    var x = prompt("username")
    document.write(x)
    }
    function bio(){
        var y=("KIRSHAN LAL")
        alert(y)
        var y=("19 year old")
        alert(y)
        var y=("Certified Mobile Application Development")
        alert(y)
    }
    function pizza(){
        var z=("PIZZA\n PIZZ \n PIZ \n PI \n P")
        alert(z)
    }
    
    function email(){
        var e=("My email address is Kunallalwani2019@gmail.com")
        alert(e)
    }
    function book(book){
        var b=("Iam trying to learn from the book A Smarter Way to learn JavaScript")
        alert(b)
    }
    function js(){
        var a=("Yeah! i can write HTML content through JavaScript")
        document.write(a)
    }
    function end(){
        var b=("“▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬”")
        alert(b)
    }function age(){
        var age;
        alert("I am 19 year old")
        }
        
        
        function counter(){
        var counter;
        alert("you have been visited this site 40 times ")
        }
        function age(){
            var age ;
            age = prompt(" Enter your date of birth")
            document.write("Date of birth "+   + age)
        }
        function sum(){
 
            var  a=  +prompt("Enter the  number")
              var b= +prompt("Enter the number")
           
           var c = a+b;
           document.write("Sum of two number " +       +c)
           
           }
           
           function sub(){
             var  c=  +prompt("Enter the  number")
             var d= +prompt("Enter the number")
           
           var b = c-d;
           var e= c*d;
           var f= c/d;
           document.write("subtraction of two number " +       +b + "<br>" )
           document.write("Multiply of two number " +       +e + "<br>")
           document.write("Division of two number " +       +f + "<br>")
           
           }
           
           
           function que(){
             var a=100;
             document.write ("Intial value "+ +a + "<br>")
           
             var a= 100;
             a++;
             document.write ("Value after  Increament "+ +a + "<br>") 
           
             var a= 100;
             a++;
             var c=a++ +100;
             document.write ("Value after addition "+ +c + "<br>")
           var d= 201
           d--;
           document.write ("Value after decrement  "+ +d + "<br>")
           
           var d=5;
           var e =5;
           var f=d%e;
           document.write ("Reminder  "+ +f + "<br>")
           }
           
           function ticket(){
             var a =+prompt("How many tickets are you buying")
             var z= a*300;
             document.write("Total cost to buy") 
             document.write(a)
           document.write( "tickets to a movie is"+    +z+    "PKR ")
           }
           function tab(){
             for (var i=1; i<=10; i++)
             {
               document.write("4" + "x" + i + "=" + 4*i + "<br>")
             }
           }
           
           function temp(){
             var a=+prompt("enter the temperature concert into Fahrenheit")
             var f=(a*9/5)+32;
             document.write(" temperature is "+ +f + "°F   <br>" ) 
             var b=+prompt("enter the temperature concert into Celsius")
             var c=(b-32)*5/9;
             document.write(" temperature is "+ +c + "°C") 
           }
           function shoping(){
             
             var item1 = +prompt(" Price of  1 item is 600 \nHow many item you are order")
           var item2 = +prompt("Price of  2 item is 700 \nHow many item you are order")
           document.write("SHOPPPING CART <br>")
           document.write ("Price of 1 item 600"   )
           document.write("<br>")
           document.write("Quantity of item "+ +item1 +"<br>")
           document.write ("Price of 2 item 700"   )
           document.write("<br>")
           document.write("Quantity of item "+ +item2 +"<br>")
           document.write("Shipping Charges  100" )
           document.write("<br>")
           var i;
             i=600*item1;
             var j;
             j=700*item2;
             var z;
             z=i+j+100;
           document.write("Total Cost of your Order is" +    + z )
           }
           
           function marks(){
             var a= +prompt("Enter your obtained marks ")
             var c=a/1100 *100;
             document.write("Total marks: 1100")
             document.write("<br>")
             document.write("Obtained marks: "+ +a +"<br>")
             document.write("Percentage:" + +c )
           }
           
           function currency(){
             var a=+prompt("How many dollars you have")
             var b=+prompt("How many Saudi Riyals you have")
             var z;
             z=a*104.80
             var x;
             x=b*28;
             var e;
             e=z+x;
             document.write("Currency in PKR")
             document.write("<br>")
             document.write("You have a:"+"  " +a+"Dollar")
             document.write("<br>")
             document.write("You have a:"+"  "+b+"Saudi Riyals")
             document.write("<br>")
             document.write("Total Currency in PKR:" +"  "+e)
           }
           
           
           
           
           
           function art(){
             var  c=  +prompt("Enter the  number")
             var d= +prompt("Enter the number")
           
           var b = c+d;
           var e= c*d;
           var f= c/d;
           document.write("Addition of two number " +       +b +"<br>")
           document.write("Multiply of two number " +       +e + "<br>")
           document.write("Division of two number " +       +f)
           
           }
           
           
           
           
           function age(){
             var a=+prompt("Enter the current year")
             var b=+prompt("Enter the birth year")
             var c; 
             c=a-b;
             document.write("Age Calculator")
             document.write("Current Year:" + +a +"<br>")
             document.write("Birth year:"+ +b +"<br>")
             document.write("your age is:"+ +c)
           }
           
           
           
           
           
           function radius(){
             var a=+prompt("Enter the Radius of Circle")
             document.write("Rdius of Circle :"+ + a +"<br>")
             var c;
             c=2*3.142*a;
             document.write("Circumference of Circle : "+ +c+"<br>")
           
             var d;
              d=3.142*r*r;
              document.write("Area of Circle :"+ +d+"<br>")
           }
           function ath(){
            var a=+prompt("Enter the value")
            document.write("The value is "+ +a+"<br>")
            document.write("------------------------------","<br>")
            var b; 
            b=++a;
            document.write("The value of ++a is :"+ +b +"<br>")
            document.write("Now the value of a is :"+ +b +"<br>","<br>","<br>","<br>")
            var c;
            c=b++;
            document.write("The value of a++ is :"+ c +"<br>") 
            document.write("Now the value of a++ is :"+ b +"<br>","<br>","<br>","<br>")
            
            var d;
            d=--b;
            document.write("The value of --a is :"+ d +"<br>")
            document.write("Now the value of --a is :"+ b +"<br>","<br>","<br>","<br>")
            var d;
            d=--a;
            document.write("The value of a-- is :"+ d +"<br>")
            document.write("Now the value of a-- is :"+ a +"<br>","<br>","<br>","<br>")
            }
            
            function incr(){
                var a =2, b=1;
                document.write("a is :"+ +a+"<br>")
                document.write("b is :"+ +b+"<br>")
              
                var c;
                c=--a- --b+ ++b +b--;
                document.write("Result is "+ + c +"<br>")
                var d;
                d=--a;
                document.write("Result is "+ + d +"<br>")
                var c;
                c=--a- --b;
                document.write("Result is "+ + c +"<br>")
                var c;
                c=--a- --b+ ++b;
                document.write("Result is "+ + c +"<br>")
                var c;
                c=--a- --b+ ++b+b--;
                document.write("Result is "+ + c +"<br>")
            }
            
            
            function tab(){
                for (var i=1;i<=10; i++){
                    document.write("5 " +"x" +i+ "="+5*i +"<br>")
                }
            
            }
            
            function text(){
                var a=prompt("Enter the 1 subject ")
                var b=+prompt("Enter the mark")
            
               var c=prompt("Enter the  2 subject")
               var d=+prompt("Enter the mark")
            
                var e=prompt("Enter the  3 subject")
                var f=+prompt("Enter the mark")
                var z;
                z=b/100*100;
                var y;
                y=d/100*100;
                var v;
            v=f/100*100;
                document.write("Subject total mark obtained  percentage ","<br>")
                document.write(a +'               '+"100"+'                  '+b + '     '+z+"%"+"<br>")
                
                document.write(c +'               '+"100"+'                  '+d+ '     '+y +"%"+"<br>")
                
                document.write(e +'               '+"100"+'                  '+f + '     '+v+"%"+"<br>")
            var h;
            h= b+d+f;
            var r;
            r=h/300*100;
            document.write("300"+ '        '+h+'         '+r )
            
            
            }
            function wel(){
                var b=prompt("Enter the city ")
                
                if (b=='karachi'){
                 document.write("Wellcome to city of light ")}
                    else {
                        document.write ("wellcome to city")
                    }
                }
            
            
            
                function gender(){
                    var b=prompt("Enter the gender ")
                
                    if (b=='male'){
                     document.write("Good morning sir  ")}
                        else {
                            document.write ("Good morning maam")
                        }
                }
            
            
                function traffic(){
                    var b=prompt("Enter the signal color ")
                
                    if (b=='red'){
                     document.write("Must Stop  ")}
                        else if(b=='yellow')  {
                            document.write ("Ready to move ")
                        }
                        else{
                            document.write("Move now")
                        }
                }
            
                function fuel(){
                    var a=+prompt("Enter the reamining fuel in your car")
                    if (a==0.25){
                        document.write("“Please refill the fuel in your car”")
                    }
                    else{
                        document.write("More fuel in your car")
                    }
                }
            
            
                function mess(){
                   
                    var a = 4; 
                    if (++a === 5)
                    { 
                        alert("given condition for variable a is true");
                     }
                     else{
                         alert("given condition for variable a is false")
                     }
                    
                    }
            
                    function mark(){
                        var a= prompt("Enter your 1 subject ")
                        var b=+prompt("enter your marks")
                        var c= prompt("Enter your  2 subject ")
                        var d=+prompt("enter your marks")
                        var e= prompt("Enter your 3 subject ")
                        var f=+prompt("enter your marks")
            var z=b+d+f/300*100;
            
            if(z<=99){
                alert("A-one")
            }
            else if(z<=70){
            alert("A")
            }
            else if(z<=60){
                alert("B")
                }
                else if(z<=50){
                    alert("C")
                    }
                    else {
                        alert("you are fail")
                    }
                    }
                
                
            function temp(){
                var a=+prompt("Enter the temperature")
                if(a>40){
                    document.write("“It is too hot outside.”")
                }
                else if(a>30){
                    document.write("“The Weather today is Normal.”")
                }
                else if(a>20){
                    document.write("“Today’s Weather is cool.”")
                }
                else{
                    document.write("“OMG! Today’s weather is so Cool.”")
                }
            
            
            
            }
            function kl(){
                var a=+prompt("enter the number")
            var i=+prompt("enter the number ")
            if(i<a){
                document.write("large number ")
            }
                else if(i>a){
                    document.write("Small number ") 
                }
                else if (i==a){
                    document.write("equal number ") 
                }
            }  
            
            function eq(){
            var a=+prompt("Enter the hour")
            var hour = 13;
             if (hour < 18)
              {
                  document.write ("Good day") }
                   else if(hour>18) {
            
                    document.write ( "Good evening") }
                    else{
                        
                    }
            
            
            }
            
            
            
            function wa(){
                var a=+prompt("enter a digit")
                if (a>1){
                    document.write("Positive number")
                }
                    else if(a<=1||a==0){
            document.write("Negative number")
                    }
                    else if (a===0){
                        document.write("zero")
                    }
                    else{
                        document.write("No digit")
                    }
                }
            
            
                function vowel(){
            var a=prompt("Enter the Character ")
            if (a == "a", "e", "i", "o", "u" ||a == "A", "E", "I", "O", "U"){
                document.write("It's Vowel")
                
            }
            /*else if (a='E'||a=='e'){
                document.write("It's Vowel")
            }
            else if (a='I'||a=='i'){
                document.write("It's Vowel")
            }
            else if (a='O'||a=='o'){
                document.write("It's Vowel")
            }
            else if (a='U'||a=='u'){
                document.write("It's Vowel")
            }
            
            {
                document.write("It's Consonent")
            }*/
            else{
                document.write("it's consonant")
            }
                }
            
            
                function pas(){
            var a=+prompt("Enter the confirm password in digit")
            var b=+prompt("Enter the confirm password")
            
            if (a==b){
                document.write("CORRECT!")
            }
            else {
                document.write("wrong")
            }
            
            
                }
            
            
                function hour(){
                    var a=+prompt("Enter the hour")
                    if (a< 18) 
                    {
                        document.write("Good day")}
                          else{
                         document.write("Good evening") }
                }
                function a(){
                    var b=["Lucy", "Izzay","Ricky","Tony"]
                    document.write("Future name" +  [b])
                    }
                    
                    
                    
                    function qec(){
                        var q=["(1) SSC" ,"<br>" ,"(2)HSC","<br>", "(3)BCS", "<br>","(4)BS","<br>", "(4)BCOM","<br>", "(5)MS","<br>", "(6)M.PHD" ,"<br>", "(7)M.PHILL"]
                        document.write(  [q])
                    }
                    
                    
                    function array(){
                        var b=prompt("enter the color")
                        var a=[]
                        document.write(+[b])
                    }
                    function count(){
                        var a;
                        for(a=1; a<=10;a++)
                        {
                            document.write(a+"<br>")
                        }
                    }
                    
                    function tab(){
                        var a=+prompt("Enter the number show to its Multiplication table")
                        var b=+prompt("Enter the length")
                        for (var i=1;i<=b;i++)
                        {
                    document.write(a + "x"+i+"="+a*i+"<br>")
                        }
                    }
                    
                    
                    function aa(){
                        var fruit = ['apple' , 'banana', 'mango', 'orange', 'strawberry']
                        document.write([fruit])
                    document.write("<br>Element at index 0 is "+fruit[0])
                    document.write("<br>Element at index 1 is "+fruit[1])
                    document.write("<br>Element at index 2 is "+fruit[2])
                    document.write("<br>Element at index 3 is "+fruit[3])
                    document.write("<br>Element at index 4 is "+fruit[4])
                    }
                    
                    
                    
                    function bc(){
                        document.write("Counting:")
                    for(var i=1;i<=15;i++)
                    {
                        document.write(","+i)
                    }
                    }
                    
                    
                    
                    function res(){
                    document.write("Reverse counting:")
                    for(var b=1;b<=15;b--)
                    {
                        document.write(","+b)
                    }
                    }
                    
                    
                    
                    function even(){
                        document.write("Even")
                        for(var x=0;x<=20;x+2){
                            document.write(","+x)
                        }
                    }
                    function odd(){
                        document.write("Even")
                        for(var x=0;x<=20;x+1){
                            document.write(","+x)
                        }
                    }
                    function q1(){
                        var a=prompt("Enter your Full name")
                        document.write("My name is: "+a)
                    }
                    
                    function q2(){
                        var a=prompt("Enter your favorite mobile phone model.")
                        document.write("My favorite mobile is: "+a)
                        var n = a.length;
                        document.write("<br>Length is :" +a.length)
                    }
                    function q2(){
                        document.write("String :Pakistan<br>")
                        var a= "String :Pakistan" 
                        var n = a.indexOf(3); 
                        document.write("Character at index  3 :" +a.charAt(3))
                    }
                    
                    
                    function q3(){
                        document.write("city : hyderabad")
                        document.write("<br>After replacement: islamabad")
                    }
                    
                    
                    function q4(){
                        var a=+prompt("enter the value ")
                        document.write("<br>Value:"+a)
                        document.write("<br>Type: number")
                    
                        var b=prompt("enter the string")
                        document.write("<br>Value:"+b)
                        document.write("<br>Type: String")
                    }
                    
                    function q7(){
                        var a=prompt("Enter the string i will convert to uppercase"  )
                    document.write("UserInput: "+a)
                        var b=a.toLocaleUpperCase(a)
                    document.write("<br>Upper case:"+a.toLocaleUpperCase(a))
                    }
                    
                    function arr(){
                    var b=prompt("Wellcome to london bakery.What do you want order ")
                        var a=['cake', 'apple' ,'pie', 'cookie', 'chips', 'patties']
                    if(a['cake', 'apple' ,'pie', 'cookie', 'chips', 'patties']===a){
                        document.write(b+"is available")
                    }
                    else{
                        document.write(b+"is not  available")
                    }
                    }
                    function myFunction() {
                        var a= +prompt("Enter the positive  float number")
                      document.write("Number       :" +a)
                      var b= innerHTML = Math.round(a);
                    
                    document.write( "<br>Round off    :"+'     ' +b)  
                    var b =Math.floor(a);
                    
                    document.write("<br>Floor    :" +b)
                    var b= Math.ceil(a);
                    document.write("<br>Ceil    :" +b)
                    }
                    
                    
                    
                    
                    
                    
                    
                    
                    function neg() {
                        var a= +prompt("Enter the negative float number")
                      document.write("Number       :" +a)
                      var b= innerHTML = Math.round(a);
                    
                    document.write( "<br>Round off    :"+'     ' +b)  
                    var b =Math.floor(a);
                    
                    document.write("<br>Floor    :" +b)
                    var b= Math.ceil(a);
                    document.write("<br>Ceil    :" +b)
                    }
                    
                    
                    
                    function ab(){
                        var a=+prompt("Enter the number ")
                        var b= Math.abs(a);
                    
                        document.write("The Absolute value value of  "+a +"is "+b)
                    }
                    
                    function coin(){
                        var head = 1;
                    var tail = 2;
                    
                    var toss = Math.random() * 2;
                    var floor = Math.floor(toss)
                    if(floor === 2){
                        document.write("0 <br> Random Coin Value: Head")
                    } else if(floor === 1)
                    {
                        document.write("1 <br> Random Coin Value: Tails")
                    }
                    
                    
                    }
                    
                    
                    function rad(){
                       var b= Math.floor(Math.random() * 100);
                    document.write("Random number between 1 to 100:"+b)
                    }
                    function dt(){
                        var d=  new Date();
                        document.write(d)
                    
                    }
                    
                    function mo(){
                        var month = new Array();
                        month[0] = "January";
                        month[1] = "February";
                        month[2] = "March";
                        month[3] = "April";
                        month[4] = "May";
                        month[5] = "June";
                        month[6] = "July";
                        month[7] = "August";
                        month[8] = "September";
                        month[9] = "October";
                        month[10] = "November";
                        month[11] = "December";
                      
                        var d = new Date();
                        var n = month[d.getMonth()];
                     document.write("Current month "+n)  
                    }
                    
                    
                    function dy(){
                        var d = new Date();
                        var weekday = new Array(7);
                        weekday[0] = "Sunday";
                        weekday[1] = "Monday";
                        weekday[2] = "Tuesday";
                        weekday[3] = "Wednesday";
                        weekday[4] = "Thursday";
                        weekday[5] = "Friday";
                        weekday[6] = "Saturday";
                        
                        var n = weekday[d.getDay()];
                        document.write("Today is "+n)
                    }
                    
                    
                    function tim(){
                    var d = new Date();
                    d.setUTCMilliseconds(192);
                    var n = d.getUTCMilliseconds();
                    document.write(n+"<br>")
                    var d = new Date();
                    d.setUTCMinutes(17);
                    document.write(d)
                    }
            
           
           
           